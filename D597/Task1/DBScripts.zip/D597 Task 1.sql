CREATE TABLE "patients" (
  "patient_id" serial PRIMARY KEY,
  "first_name" varchar,
  "last_name" varchar,
  "date_of_birth" date,
  "gender" char,
  "medications" boolean,
  "last_appointment_date" date
);

CREATE TABLE "medical_conditions" (
  "condition_id" serial PRIMARY KEY,
  "condition_name" varchar
);

CREATE TABLE "allergies" (
  "allergy_id" serial PRIMARY KEY,
  "allergy_name" varchar
);

CREATE TABLE "brands" (
  "brand_id" serial PRIMARY KEY,
  "brand_name" varchar
);

CREATE TABLE "device_types" (
  "device_type_id" serial PRIMARY KEY,
  "device_type_name" varchar
);

CREATE TABLE "display_types" (
  "display_type_id" serial PRIMARY KEY,
  "display_type_name" varchar
);

CREATE TABLE "strap_types" (
  "strap_type_id" serial PRIMARY KEY,
  "strap_material_name" varchar
);

CREATE TABLE "models" (
  "model_id" serial PRIMARY KEY,
  "brand_id" integer,
  "device_type_id" integer,
  "model_name" varchar
);

CREATE TABLE "model_configurations" (
  "config_id" serial PRIMARY KEY,
  "model_id" integer,
  "display_type_id" integer,
  "strap_type_id" integer,
  "config_color" varchar,
  "config_selling_price" decimal(9,0),
  "config_original_price" decimal(9,0),
  "config_avg_battery_life" integer,
  "config_rating" decimal(3,1),
  "config_reviews" integer
);

CREATE TABLE "patients_medical_conditions" (
  "patients_patient_id" serial,
  "medical_conditions_condition_id" serial,
  PRIMARY KEY ("patients_patient_id", "medical_conditions_condition_id")
);

ALTER TABLE "patients_medical_conditions" ADD FOREIGN KEY ("patients_patient_id") REFERENCES "patients" ("patient_id");

ALTER TABLE "patients_medical_conditions" ADD FOREIGN KEY ("medical_conditions_condition_id") REFERENCES "medical_conditions" ("condition_id");


CREATE TABLE "patients_allergies" (
  "patients_patient_id" serial,
  "allergies_allergy_id" serial,
  PRIMARY KEY ("patients_patient_id", "allergies_allergy_id")
);

ALTER TABLE "patients_allergies" ADD FOREIGN KEY ("patients_patient_id") REFERENCES "patients" ("patient_id");

ALTER TABLE "patients_allergies" ADD FOREIGN KEY ("allergies_allergy_id") REFERENCES "allergies" ("allergy_id");


ALTER TABLE "models" ADD FOREIGN KEY ("brand_id") REFERENCES "brands" ("brand_id");

ALTER TABLE "models" ADD FOREIGN KEY ("device_type_id") REFERENCES "device_types" ("device_type_id");

ALTER TABLE "model_configurations" ADD FOREIGN KEY ("model_id") REFERENCES "models" ("model_id");

ALTER TABLE "model_configurations" ADD FOREIGN KEY ("display_type_id") REFERENCES "display_types" ("display_type_id");

ALTER TABLE "model_configurations" ADD FOREIGN KEY ("strap_type_id") REFERENCES "strap_types" ("strap_type_id");

CREATE TABLE "patients_models" (
  "patients_patient_id" serial,
  "models_model_id" serial,
  PRIMARY KEY ("patients_patient_id", "models_model_id")
);

ALTER TABLE "patients_models" ADD FOREIGN KEY ("patients_patient_id") REFERENCES "patients" ("patient_id");

ALTER TABLE "patients_models" ADD FOREIGN KEY ("models_model_id") REFERENCES "models" ("model_id");

