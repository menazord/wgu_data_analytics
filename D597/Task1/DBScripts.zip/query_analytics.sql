-- Find the distribution of patients by allergy type
SELECT a.allergy_name, count(p.patient_id)
  FROM allergies a
  JOIN patients_allergies pa ON a.allergy_id = pa.allergies_allergy_id
  JOIN patients p ON pa.patients_patient_id = p.patient_id
GROUP BY a.allergy_name
ORDER BY a.allergy_name;

-- Find the distribution of device brands by users
SELECT b.brand_name, count(pm.patients_patient_id) as totals
  FROM brands b
  JOIN models m ON b.brand_id = m.brand_id
  JOIN patients_models pm ON m.model_id = pm.models_model_id
 GROUP BY b.brand_name
 ORDER BY count(pm.patients_patient_id) desc;

-- Find how many Gen X and Millenial patients are using trackers
explain SELECT count(1)
  FROM patients
 WHERE date_of_birth BETWEEN '01-01-1965' AND '12-31-1980';

CREATE INDEX dob_idx ON patients (date_of_birth);
