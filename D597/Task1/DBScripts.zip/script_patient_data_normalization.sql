-- Create table for raw data
CREATE TABLE "raw_patients" (
                            "patient_id" integer PRIMARY KEY,
                            "name" varchar,
                            "date_of_birth" date,
                            "gender" char,
                            "medical_conditions" varchar,
                            "medications" varchar,
                            "allergies" varchar,
                            "last_appointment_date" date,
                            "tracker" varchar
);

-- import raw data to raw table
COPY raw_patients(patient_id, name, date_of_birth, gender, medical_conditions, medications, allergies, last_appointment_date, tracker)
FROM '/tmp/patients.csv'
DELIMITER ','
CSV HEADER;

-- Validate record count (expected 100,000) 
select count(1) from raw_patients;

-- insert raw patient data into patient
INSERT INTO patients(patient_id, first_name, last_name, date_of_birth, gender, medications, last_appointment_date)
SELECT patient_id, split_part(name,' ',1), split_part(name,' ',2), date_of_birth, gender,
       CASE
           WHEN medications = 'Yes' THEN true
           ELSE false
       END,
       last_appointment_date
from raw_patients;

-- normalize patient allergies
SELECT distinct(allergies) FROM raw_patients;

INSERT INTO allergies(allergy_name) SELECT distinct(allergies) FROM raw_patients;

SELECT * from raw_patients limit 10;

INSERT INTO patients_allergies
SELECT patient_id, allergy_id
  FROM raw_patients p
  JOIN allergies a
    on p.allergies = a.allergy_name;

-- normalize medical conditions
SELECT distinct(medical_conditions) FROM raw_patients;

INSERT INTO medical_conditions(condition_name) SELECT distinct(medical_conditions) FROM raw_patients;

INSERT INTO patients_medical_conditions
SELECT patient_id, condition_id
  FROM raw_patients p
  JOIN medical_conditions m
    ON p.medical_conditions = m.condition_name;

-- test nornalization with a single patient
SELECT p.*, a.allergy_name, m.condition_name
  FROM patients p
  JOIN patients_medical_conditions pm
    ON p.patient_id = pm.patients_patient_id
  JOIN medical_conditions m
   ON pm.medical_conditions_condition_id = m.condition_id
  JOIN patients_allergies pa
    ON p.patient_id = pa.patients_patient_id
  JOIN allergies a
    ON pa.allergies_allergy_id = a.allergy_id
WHERE p.patient_id = 64;
