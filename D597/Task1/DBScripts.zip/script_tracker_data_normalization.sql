-- Create table for raw data
CREATE TABLE "raw_trackers" (
                                "brand_name" varchar,
                                "tracker_type" varchar,
                                "model_name" varchar,
                                "color" varchar,
                                "selling_price" varchar,
                                "original_price" varchar,
                                "display_type" varchar,
                                "rating" decimal (3,1),
                                "strap_type" varchar,
                                "avg_battery" integer,
                                "reviews" varchar
);

-- import raw data to raw table
COPY raw_trackers(brand_name, tracker_type, model_name, color, selling_price, original_price, display_type, rating, strap_type, avg_battery, reviews)
    FROM '/tmp/trackers.csv'
    DELIMITER ','
    CSV HEADER;

-- Validate record count (expected 565) 
select count(1) from raw_trackers;

-- normalize device brands
SELECT DISTINCT(TRIM(brand_name)) FROM raw_trackers ORDER BY TRIM(brand_name);

INSERT INTO brands(brand_name) SELECT DISTINCT(TRIM(brand_name)) FROM raw_trackers;

-- normalize device types
SELECT DISTINCT(tracker_type) FROM raw_trackers;

INSERT INTO device_types(device_type_name) SELECT DISTINCT(tracker_type) FROM raw_trackers;

-- normalize display types

SELECT DISTINCT(display_type) FROM raw_trackers ORDER BY display_type;

INSERT INTO display_types(display_type_name) SELECT DISTINCT(display_type) FROM raw_trackers;

-- normalize strap types

SELECT DISTINCT(UPPER(TRIM(strap_type))) FROM raw_trackers ORDER BY UPPER(TRIM(strap_type));

INSERT INTO strap_types(strap_material_name) SELECT DISTINCT(UPPER(TRIM(strap_type))) FROM raw_trackers;


-- insert normalized device model data
INSERT INTO models(model_name, brand_id, device_type_id)
SELECT DISTINCT(model_name), b.brand_id, dev.device_type_id
  FROM raw_trackers r
  JOIN brands b ON TRIM(r.brand_name) = b.brand_name
  JOIN device_types dev ON r.tracker_type = dev.device_type_name;

-- validate model data
SELECT m.model_id, b.brand_name, d.device_type_name, m.model_name
  FROM models m
  JOIN brands b ON m.brand_id = b.brand_id
  JOIN device_types d ON m.device_type_id = d.device_type_id
  WHERE model_name = 'Band 3';

-- insert nornalized model volatile attributes
INSERT INTO model_configurations(model_id, display_type_id, strap_type_id, config_color, config_selling_price, config_original_price, config_avg_battery_life, config_rating, config_reviews)
SELECT m.model_id, dt.display_type_id, st.strap_type_id,
       color, TO_NUMBER(selling_price, '99G999'), TO_NUMBER(original_price, '99G999'),
       avg_battery, rating, TO_NUMBER(reviews, '99G999')
  FROM raw_trackers r
  JOIN models m ON r.model_name = m.model_name
  JOIN display_types dt ON r.display_type = dt.display_type_name
  JOIN strap_types st ON UPPER(TRIM(r.strap_type)) = st.strap_material_name;

-- validate model with attributes
SELECT m.model_id, b.brand_name, d.device_type_name, m.model_name, c.config_color, c.config_selling_price, c.config_original_price,
       dt.display_type_name, st.strap_material_name, config_avg_battery_life, config_rating, config_reviews
  FROM models m
  JOIN brands b ON m.brand_id = b.brand_id
  JOIN device_types d ON m.device_type_id = d.device_type_id
  JOIN model_configurations c ON m.model_id = c.model_id
  JOIN display_types dt ON c.display_type_id = dt.display_type_id
  JOIN strap_types st ON c.strap_type_id = st.strap_type_id
 WHERE m.model_name = 'Amazfit Bip';

