-- Consolidate patient to models relatioships
INSERT INTO patients_models(patients_patient_id, models_model_id)
SELECT r.patient_id, m.model_id
  FROM raw_patients r
  JOIN models m ON r.tracker = m.model_name;

-- validate with a use case
SELECT p.*, a.allergy_name, mc.condition_name, m.model_name
  FROM patients p
  JOIN patients_medical_conditions pmc ON p.patient_id = pmc.patients_patient_id
  JOIN medical_conditions mc ON pmc.medical_conditions_condition_id = mc.condition_id
  JOIN patients_allergies pa ON p.patient_id = pa.patients_patient_id
  JOIN allergies a ON pa.allergies_allergy_id = a.allergy_id
  JOIN patients_models pm ON p.patient_id = pm.patients_patient_id
  JOIN models m ON pm.models_model_id = m.model_id
 WHERE p.patient_id = 100;
